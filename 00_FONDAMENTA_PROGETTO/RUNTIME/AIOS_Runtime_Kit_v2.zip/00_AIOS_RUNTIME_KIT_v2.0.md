Documento: 00_AIOS_RUNTIME_KIT Versione: v2.0 Sistema: AIOS Tipo:
Runtime Kit Anno: 2026

# 1 --- SCOPO

Il Runtime Kit contiene i documenti minimi necessari per avviare una
sessione AIOS stabile.

# 2 --- DOCUMENTI DEL RUNTIME KIT

## 00_SYSTEM

-   00_AIOS_KERNEL_MANIFEST
-   00_AIOS_RUNTIME_OPERATING_LAYER
-   00_AIOS_BOOT_SEQUENCE
-   00_AIOS_META_OBSERVATION
-   00_AIOS_SYSTEM_MAP
-   00_AIOS_ROOT_STRUCTURE

## 01_METHOD

-   01_AIOS_METHOD
-   01_AIOS_SESSION_PROTOCOL
-   01_AIOS_STATE_PROTOCOL

## 02_PROTOCOLS

-   02_AIOS_CHAT_ANCHOR_PROTOCOL
-   02_AIOS_CQD_PROTOCOL

# 3 --- DOCUMENTI ESCLUSI DAL RUNTIME

Caricabili su richiesta: - STP Protocol - Project Launch Protocol -
Sistema Fonti - Incident Management - Dashboard - Project Index - Radar
System

# VERSION HISTORY

v2.0 --- Runtime ridefinito con Kernel Manifest
