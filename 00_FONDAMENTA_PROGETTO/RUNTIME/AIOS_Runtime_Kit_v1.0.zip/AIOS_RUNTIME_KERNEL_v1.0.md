# AIOS_RUNTIME_KERNEL_v1.0

Scopo
Definire il comportamento runtime vincolante del sistema AIOS durante le sessioni conversazionali.

Principio
Il Runtime Kernel è il layer che attiva i protocolli AIOS durante la conversazione.

Sequenza operativa runtime

BOOT
↓
RUNTIME
↓
SESSION
↓
ANCHOR
↓
DOCUMENT
↓
STATE
↓
SWITCH

Regole runtime

1. All'avvio (#start) viene eseguita la Boot Sequence.
2. Il sistema verifica la presenza del Kernel Documentale.
3. La Meta‑Observation viene attivata automaticamente.
4. Gli Anchor vengono suggeriti quando emergono:
   decisioni, strutture, contenuti documentali, task.
5. Se la conversazione supera limiti di complessità:
   suggerire #state oppure #switch.
6. Ogni decisione strutturale può attivare STP.
7. Ogni documento passa tramite CQD.
8. Lo STATE deve essere aggiornato quando cambia nodo operativo.

Meta‑Observation Engine

Controlli runtime:

SOFT CHECK
segnala possibile deriva conversazionale

MEDIUM CHECK
identifica decisioni implicite

ALERT CHECKPOINT
richiede consolidamento (#state)

Switch Protocol

Quando la sessione diventa lunga o instabile:

1 generare #state
2 generare Anchor Register
3 preparare #switch

La nuova chat deve ricevere:

Bootstrap
Runtime Kernel
eventuali documenti progetto.