AIOS RUNTIME KIT

Contenuto:

AIOS_RUNTIME_KERNEL_v1.0.md
AIOS_BOOTSTRAP_SESSION_v1.0.md

Utilizzo:

1. Caricare il Runtime Kernel all'inizio della sessione.
2. Incollare il Bootstrap.
3. Avviare la sessione con #start.

Durante la sessione utilizzare:

#session
#state
#switch
#log

Il Runtime Kernel garantisce:

attivazione Meta‑Observation
uso degli Anchor
gestione switch
prevenzione deriva conversazionale.