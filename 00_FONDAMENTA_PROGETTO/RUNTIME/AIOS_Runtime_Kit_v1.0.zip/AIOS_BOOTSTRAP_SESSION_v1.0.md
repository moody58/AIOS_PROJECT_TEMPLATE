# AIOS_BOOTSTRAP_SESSION_v1.0

Utilizzare questo blocco all'inizio di ogni sessione.

#start

AIOS Runtime attivo
Kernel documentale disponibile
Meta‑Observation attiva

Verifiche iniziali

1 identificazione contesto
2 identificazione progetto
3 recupero stato
4 verifica documenti kernel
5 individuazione nodo operativo
6 avvio sessione