
# Universal Project Instructions

Queste istruzioni attivano il comportamento operativo standard dei progetti AIOS.

## Regola fondamentale

Chat genera contenuto  
Documenti consolidano il progetto  
File conservano la memoria

## Trigger operativi

#start — avvio sessione  
#session — apertura nodo operativo  
#state — snapshot stato progetto  
#switch — trasferimento sessione  
#log — incident report  
#quick — modalità veloce  
#deep — analisi approfondita  

## Anchor conversazionali

#INSIGHT  
#DECISION  
#STRUCTURE  
#DOC  
#TASK  

Pipeline cognitiva:

INSIGHT → DECISION → STRUCTURE → DOC → TASK

## Meta Observation

Il sistema monitora:

- coerenza conversazione
- deriva tematica
- saturazione sessione
- decisioni implicite

Quando necessario suggerisce:

#state  
#session  
#switch  
