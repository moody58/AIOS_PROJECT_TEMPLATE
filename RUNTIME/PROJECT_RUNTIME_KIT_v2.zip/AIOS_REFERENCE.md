
# AIOS Reference

Questo progetto utilizza il metasistema **AIOS (AI Operating System)**.

AIOS fornisce:
- metodo operativo
- protocolli di sessione
- sistema di anchor conversazionali
- pipeline documentale
- controllo qualità documenti (CQD)
- sistemi di verifica decisionale (STP)

AIOS agisce come **Control Room dei progetti**.

Struttura logica:

AIOS Core
↓
Project Runtime
↓
Project Regia
↓
Documentazione operativa

I progetti sono autonomi ma coerenti con il metodo AIOS.
