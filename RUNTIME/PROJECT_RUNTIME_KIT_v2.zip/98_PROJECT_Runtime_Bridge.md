
# Project Runtime Bridge

Questo documento collega il runtime del progetto al sistema AIOS.

Flusso logico:

AIOS Kernel
↓
Project Runtime
↓
Regia del progetto
↓
Documenti operativi

## Attivazione

Durante il trigger:

#start

il sistema:

1. identifica il progetto
2. attiva il runtime del progetto
3. verifica lo stato del progetto
4. apre la sessione operativa

Il runtime bridge garantisce che il progetto utilizzi
il metodo AIOS senza dover caricare manualmente
tutti i documenti del kernel.
